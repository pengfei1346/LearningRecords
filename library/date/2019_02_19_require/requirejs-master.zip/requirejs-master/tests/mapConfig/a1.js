define(['c', 'c/sub'], function (c, csub) {
    return {
        c: c,
        csub: csub
    };
});
