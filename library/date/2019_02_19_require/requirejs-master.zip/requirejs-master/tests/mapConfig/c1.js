define({
    name: 'c1'
});
