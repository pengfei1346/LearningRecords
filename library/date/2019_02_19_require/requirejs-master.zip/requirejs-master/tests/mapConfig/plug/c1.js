define({
    name: 'plug!c1'
});
