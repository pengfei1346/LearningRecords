define(function (require) {
    var b = require ('../dotTrim/b')// a comment right against the require

    return {
        name: 'a',
        b: b
    };
});
