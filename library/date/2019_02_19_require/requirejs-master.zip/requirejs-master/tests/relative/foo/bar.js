define({
    name: 'bar'
});
