define(function (require, exports) {
    //Create circular dependency here
    var main = require('../../packages/optimizing/main');

    exports.name = 'helper';
});
