define(['./helper'], function (helper) {
    return {
        name: 'baz',
        helper: helper
    };
});
