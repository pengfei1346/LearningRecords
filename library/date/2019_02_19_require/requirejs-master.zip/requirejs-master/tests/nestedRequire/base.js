define({
    name: 'base'
});
