define({
    name: "green"
});
