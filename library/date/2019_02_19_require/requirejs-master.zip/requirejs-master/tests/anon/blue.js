define(function () {
    return {
        name: "blue"
    };
});