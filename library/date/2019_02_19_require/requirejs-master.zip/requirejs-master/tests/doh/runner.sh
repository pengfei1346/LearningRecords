#!/bin/sh

java -jar ../../build/lib/rhino/js.jar runner.js "$@"
