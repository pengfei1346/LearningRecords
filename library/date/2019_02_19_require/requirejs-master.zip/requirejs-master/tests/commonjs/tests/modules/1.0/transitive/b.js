define(["require", "exports", "module", "../../../../../plugins/c"], function(require, exports, module) {
exports.foo = require('../../../../../plugins/c').foo;

});
