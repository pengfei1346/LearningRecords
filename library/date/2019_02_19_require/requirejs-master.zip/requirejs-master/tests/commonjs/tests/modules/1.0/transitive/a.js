define(["require", "exports", "module", "../../../../../dotTrim/b"], function(require, exports, module) {
exports.foo = require('../../../../../dotTrim/b').foo;

});
