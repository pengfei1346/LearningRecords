define(["require", "exports", "module", "../../../../../../dotTrim/b"], function(require, exports, module) {
exports.foo = function () {
    return require('../../../../../../dotTrim/b');
};

});
