define(["require", "exports", "module", "../../../../../trailingComma/a"], function(require, exports, module) {
var a = require('../../../../../trailingComma/a');
exports.b = function () {
    return a;
};

});
