define(['text!component.html'], function (html) {
    return {
        name: 'component',
        html: html
    };
});

