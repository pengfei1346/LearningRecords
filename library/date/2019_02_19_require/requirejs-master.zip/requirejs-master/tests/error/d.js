define(['../dotTrim/b'], function (b) {
    return {
       name: 'd',
       b: b
    };
});

