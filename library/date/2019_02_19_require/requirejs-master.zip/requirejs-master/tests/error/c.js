define(['../trailingComma/a'], function (a) {
    return {
       name: 'c',
       a: a
    };
});
