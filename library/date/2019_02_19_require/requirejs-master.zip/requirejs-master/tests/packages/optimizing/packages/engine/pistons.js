define({
    name: 'pistons'
});