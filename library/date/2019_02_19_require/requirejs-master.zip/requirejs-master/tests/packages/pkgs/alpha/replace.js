define({
    name: 'alpha/replace'
});
